<?php
namespace Opencart\Admin\Controller\Extension\perfectmoney\Payment;
class perfectmoney extends \Opencart\System\Engine\Controller {
		
		private $error = array();
		private $version = 'v2.0.0';
		public function index(){

		$this->load->language('extension/perfectmoney/payment/perfectmoney');

		$this->document->setTitle($this->language->get('page_title'));
		
		
		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/perfectmoney/payment/perfectmoney', 'user_token=' . $this->session->data['user_token'])
		];

		///
		$data['heading_title']=$this->language->get('heading_title');

		$data['text_edit']=$this->language->get('text_edit');
		$data['text_enabled']=$this->language->get('text_enabled');
		$data['text_disabled']=$this->language->get('text_disabled');
		$data['text_all_zones']=$this->language->get('text_all_zones');
		
		$data['entry_merchant']=$this->language->get('entry_merchant');
		$data['entry_payee_name']=$this->language->get('entry_payee_name');
		$data['entry_passphrase']=$this->language->get('entry_passphrase');
		$data['entry_total']=$this->language->get('entry_total');	
		$data['entry_order_status']=$this->language->get('entry_order_status');
		$data['entry_geo_zone']=$this->language->get('entry_geo_zone');
		$data['entry_status']=$this->language->get('entry_status');
		$data['entry_sort_order']=$this->language->get('entry_sort_order');
		
		$data['help_merchant']=$this->language->get('help_merchant');
		$data['help_passphrase']=$this->language->get('help_passphrase');
		$data['help_total']=$this->language->get('help_total');

		$data['button_save']=$this->language->get('button_save');
		$data['button_cancel']=$this->language->get('button_cancel');

 	
		
		$data['save'] = $this->url->link('extension/perfectmoney/payment/perfectmoney|save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');
		$data['user_token'] = $this->session->data['user_token'];
		
		
	
			$data['payment_perfectmoney_payee_account']=$this->config->get('payment_perfectmoney_payee_account');
			$data['payment_perfectmoney_payee_name']=$this->config->get('payment_perfectmoney_payee_name');
			$data['payment_perfectmoney_passphrase']=$this->config->get('payment_perfectmoney_passphrase');
			//$data['payment_perfectmoney_type']=$this->config->get('payment_perfectmoney_type');
			$data['payment_perfectmoney_total']=$this->config->get('payment_perfectmoney_total'); 
			$data['payment_perfectmoney_order_status_id']=$this->config->get('payment_perfectmoney_order_status_id'); 
			$data['payment_perfectmoney_geo_zone_id']=$this->config->get('payment_perfectmoney_geo_zone_id'); 
			$data['payment_perfectmoney_status']=$this->config->get('payment_perfectmoney_status');
			$data['payment_perfectmoney_sort_order']=$this->config->get('payment_perfectmoney_sort_order');


		$this->load->model('localisation/order_status');
		$data['order_statuses']=$this->model_localisation_order_status->getOrderStatuses();
				
		$this->load->model('localisation/geo_zone');
		$data['geo_zones']=$this->model_localisation_geo_zone->getGeoZones();
						
		//end
		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/perfectmoney/payment/perfectmoney', $data));

	}

	public function save(): void {
		$this->load->language('extension/perfectmoney/payment/perfectmoney');

		
		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/perfectmoney/payment/perfectmoney')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['payment_perfectmoney_payee_account']) {
			$json['error']['merchant'] = $this->language->get('error_merchant');
		}
		
		if (!$this->request->post['payment_perfectmoney_payee_name']) {
			$json['error']['payeename'] = $this->language->get('error_payee_name');
		}
		
		if (!$this->request->post['payment_perfectmoney_passphrase']) {
			$json['error']['passphrase'] = $this->language->get('error_passphrase');
		}
		
		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('payment_perfectmoney', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}


}


?>
<?php
// Heading
$_['page_title']           = 'Perfect Money';
$_['heading_title']    		  = '<a href="https://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];
// Text
$_['text_edit']               = 'Редактирование оплаты Perfect Money';
$_['text_extension']            = 'Модули';
$_['text_success']            = 'Настройки Perfect Money успешно сохранены!';   
$_['text_perfectmoney']       = '<a href="https://www.perfectmoney.is/" target="_blank"><img src="view/image/payment/perfectmoney.png" alt="Perfect Money" title="Perfect Money" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant']          = 'ID счета';
$_['entry_payee_name']        = 'Имя Аккаунта';
$_['entry_passphrase']        = 'Альтернативная кодовая фраза';
$_['entry_total']             = 'Минимальная сумма заказа';
$_['entry_order_status']      = 'Статус заказа после оплаты';
$_['entry_geo_zone']          = 'Геозона';
$_['entry_status']            = 'Статус';
$_['entry_sort_order']        = 'Порядок';

// Help
$_['help_merchant']           = 'Например, U12345678';
$_['help_passphrase']    	  = 'Альтернативная кодовая фраза можно найти и/или установить в разделе «Настройки» учетной записи PM.';
$_['help_total']              = 'Минимальная сумма, когда этот способ оплаты станет доступным';

// Error
$_['error_permission']        = 'У вас нет прав для управления модулемІІ!';
$_['error_merchant']          = 'ID счета обязательно!';
$_['error_payee_name']        = 'Имя Аккаунта обязательно!';
$_['error_passphrase']        = 'Альтернативная кодовая фраза обязательно!';
?>
<?php
// Heading
$_['page_title']              = 'Perfect Money';
$_['heading_title']    		  = '<a href="https://opencart3x.ru" target="_blank" title="Developer Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];
// Text
$_['text_edit']               = 'Fill in all the fields to enable Perfect Money payment method';
$_['text_extension']          = 'Extension';
$_['text_success']            = 'Success: You have modified Perfect Money merchant account details!';   
$_['text_perfectmoney']       = '<a href="https://www.perfectmoney.is/" target="_blank"><img src="view/image/payment/perfectmoney.png" alt="Perfect Money" title="Perfect Money" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant']          = 'Merchant account ID';
$_['entry_payee_name']        = 'PM Payee name';
$_['entry_passphrase']        = 'Alternate PassPhrase';
$_['entry_total']             = 'Total';
$_['entry_order_status']      = 'Order Status';
$_['entry_geo_zone']          = 'Geo Zone';
$_['entry_status']            = 'Status';
$_['entry_sort_order']        = 'Sort Order';

// Help
$_['help_merchant']           = 'Like U12345678';
$_['help_passphrase']    	  = 'Alternate PassPhrase can be found and set under Settings section of PM account.';
$_['help_total']              = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']        = 'Warning: You do not have permission to modify Perfect Money payment method!';
$_['error_merchant']          = 'Account ID Required!';
$_['error_payee_name']        = 'Payee name Required!';
$_['error_passphrase']        = 'Alternate PassPhrase Required!';
?>
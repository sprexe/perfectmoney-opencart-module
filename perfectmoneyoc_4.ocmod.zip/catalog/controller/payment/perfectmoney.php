<?php
namespace Opencart\Catalog\Controller\Extension\perfectmoney\Payment;
class Perfectmoney extends \Opencart\System\Engine\Controller {
	public function index(): string {
		
		$this->load->model('checkout/order');
		
		$order_info=$this->model_checkout_order->getOrder($this->session->data['order_id']);

		$allowed_cur=array('USD', 'EUR');
		$currency=$order_info['currency_code'];
		if(!in_array($currency, $allowed_cur)){
			die('currency not supported');
		}

		$data['form_action']='https://perfectmoney.is/api/step1.asp';

		$data['form_vars']['PAYEE_ACCOUNT']=$this->config->get('payment_perfectmoney_payee_account');
		$data['form_vars']['PAYEE_NAME']=$this->config->get('payment_perfectmoney_payee_name');
		$data['form_vars']['PAYMENT_UNITS']=$currency;
		$data['form_vars']['STATUS_URL']=$this->url->link('extension/perfectmoney/payment/perfectmoney/callback', '', true);
		$data['form_vars']['PAYMENT_URL']=$this->url->link('checkout/success', '', true);
		$data['form_vars']['PAYMENT_URL_METHOD']='LINK';
		$data['form_vars']['NOPAYMENT_URL']=$this->url->link('checkout/failure');
		$data['form_vars']['NOPAYMENT_URL_METHOD']='LINK';
		$data['form_vars']['SUGGESTED_MEMO']=$this->config->get('payment_perfectmoney_payee_name').' ('.$this->session->data['order_id'].')';
		$data['form_vars']['PAYMENT_ID']=$this->session->data['order_id'];
		$data['form_vars']['PAYMENT_AMOUNT']=$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

		$data['button_confirm']=$this->language->get('button_confirm');
		
		return $this->load->view('extension/perfectmoney/payment/perfectmoney', $data);
		
	}

	public function callback(){
		@define('payment_perfectmoney_DEBUG_STATUS_URL', 0);
		
		if(isset($this->request->post['PAYMENT_ID'])){
			$order_id=(int)$this->request->post['PAYMENT_ID'];
		}else{
			$this->log->write("IP: {$_SERVER['REMOTE_ADDR']}; Bad request");
			die('');
		}
 
		$this->load->model('checkout/order');
 
		$order_info=$this->model_checkout_order->getOrder($order_id);
 
		$string=
			  $this->request->post['PAYMENT_ID'].':'.$this->request->post['PAYEE_ACCOUNT'].':'.
			  $this->request->post['PAYMENT_AMOUNT'].':'.$this->request->post['PAYMENT_UNITS'].':'.
			  $this->request->post['PAYMENT_BATCH_NUM'].':'.
			  $this->request->post['PAYER_ACCOUNT'].':'.strtoupper(md5($this->config->get('payment_perfectmoney_passphrase'))).':'.
			  $this->request->post['TIMESTAMPGMT'];

		$hash=strtoupper(md5($string));

		if($hash==$this->request->post['V2_HASH']){ // processing payment if only hash is valid

		   if($this->request->post['PAYMENT_AMOUNT']==$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false) && $this->request->post['PAYEE_ACCOUNT']==$this->config->get('payment_perfectmoney_payee_account') && $this->request->post['PAYMENT_UNITS']==$order_info['currency_code']){
	
			  if(payment_perfectmoney_DEBUG_STATUS_URL==1) $this->log->write("IP: {$_SERVER['REMOTE_ADDR']}; OK!; POST: ".serialize($this->request->post)."; STRING: $string; HASH: $hash\n");

			  $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_perfectmoney_order_status_id'));

		   }else{ // you can also save invalid payments for debug purposes

			  if(payment_perfectmoney_DEBUG_STATUS_URL==1) $this->log->write("IP: {$_SERVER['REMOTE_ADDR']}; ERROR REASON: fake data; POST: ".serialize($this->request->post)."; STRING: $string; HASH: $hash\n".
			  '	IN AMOUNT: '.$this->request->post['PAYMENT_AMOUNT'].' and ORDER AMOUNT: '.$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false)."\n".
			  '	IN ACCOUNT: '.$this->request->post['PAYEE_ACCOUNT'].' and ORDER ACCOUNT: '.$this->config->get('payment_perfectmoney_payee_account')."\n".
			  '	IN UNITS:'.$this->request->post['PAYMENT_UNITS'].' and ORDER UNITS: '.$order_info['currency_code']."\n");

		   }


		}else{ // you can also save invalid payments for debug purposes

		   if(payment_perfectmoney_DEBUG_STATUS_URL==1) $this->log->write("IP: {$_SERVER['REMOTE_ADDR']}; ERROR REASON: bad hash; POST: ".serialize($this->request->post)."; STRING: $string; HASH: $hash\n");

		}


	}
}
?>